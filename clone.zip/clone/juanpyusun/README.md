# 💫 Acerca de mi:
🔭 Actualmente me encuentro realizando un tecnologo en Analisis y desarrollo de software<br>👯 Estoy en busqueda de colaborar en proyectos de software y educativos<br>🤝 Busco ayudar en el aprendizaje, compartiendo herramientas y conocimiento<br>🌱 Me encuentro aprendiendo Python de manera avanzada<br>💬 Puedes consultarme sobre Matematicas basicas y avanzadas, ciencia de datos, programacion en Python o herramientas para tus desarrollos <br>⚡ Colecciono cursos y paginas utiles :smile:


## 🌐 Socials:


# 💻 Tecnologias Aprendidas:

<img src="https://skillicons.dev/icons?i=git,github"/> <br>
<img src="https://skillicons.dev/icons?i=md,latex,regex"/> <br>
<img src="https://skillicons.dev/icons?i=html,css,js,php"/> <br>
<img src="https://skillicons.dev/icons?i=py"/> ![Anaconda](https://img.shields.io/badge/Anaconda-%2344A833.svg?style=flat&logo=anaconda&logoColor=white) ![Django](https://img.shields.io/badge/django-%23092E20.svg?style=flat&logo=django&logoColor=white) ![Flask](https://img.shields.io/badge/flask-%23000.svg?style=flat&logo=flask&logoColor=white) ![Pandas](https://img.shields.io/badge/pandas-%23150458.svg?style=flat&logo=pandas&logoColor=white) ![NumPy](https://img.shields.io/badge/numpy-%23013243.svg?style=flat&logo=numpy&logoColor=white) ![Plotly](https://img.shields.io/badge/Plotly-%233F4F75.svg?style=flat&logo=plotly&logoColor=white)<br>


# 📊 GitHub Estadisticas:
![](https://github-readme-stats.vercel.app/api?username=juanpyusun&theme=dark&hide_border=false&include_all_commits=false&count_private=false)<br/>
![](https://github-readme-streak-stats.herokuapp.com/?user=juanpyusun&theme=dark&hide_border=false)<br/>
![](https://github-readme-stats.vercel.app/api/top-langs/?username=juanpyusun&theme=dark&hide_border=false&include_all_commits=false&count_private=false&layout=compact)

---
[![](https://visitcount.itsvg.in/api?id=juanpyusun&icon=5&color=1)](https://visitcount.itsvg.in)
